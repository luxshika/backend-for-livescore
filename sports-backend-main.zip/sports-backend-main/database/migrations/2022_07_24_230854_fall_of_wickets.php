<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class FallOfWickets extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        // "Pid": 5736,
        //             "Bid": 13045,
        //             "R": 290,
        //             "B": 81.2,
        //             "Wk": 23,
        //             "WkN": 6,
        //             "Co": ""
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
